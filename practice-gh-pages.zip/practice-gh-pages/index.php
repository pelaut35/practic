

<?php 
 $p = 'Приветствую Вас на моей страничке!';
?>

<?php 
 $name = 'Андрей';
 $surname = 'Шевченко';
 $city = 'Ульяновск';
 $age = 17;
?>


<?php
include 'main.php';
?>
